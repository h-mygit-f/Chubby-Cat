
// content/toolbar/styles.js
// DEPRECATED: This file is no longer used.
// Styles are now loaded modularly from content/toolbar/styles/ directory via manifest.json.
// See content/toolbar/styles/index.js for the main entry point.
