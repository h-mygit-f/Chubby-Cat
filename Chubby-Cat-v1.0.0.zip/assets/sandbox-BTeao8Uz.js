const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/session_manager-p50RkTWB.js","assets/modulepreload-polyfill-B5Qt9EMX.js","assets/ui_controller-CitP4XpQ.js","assets/clipboard-CkaJxWJN.js","assets/app_controller-BZmRmxMP.js"])))=>i.map(i=>d[i]);
import"./modulepreload-polyfill-B5Qt9EMX.js";(function(){try{const t=new URLSearchParams(window.location.search),e=t.get("theme"),o=t.get("lang"),i=window.matchMedia("(prefers-color-scheme: dark)").matches;(e==="dark"||e==="system"&&i)&&document.documentElement.setAttribute("data-theme","dark"),o&&o!=="system"?document.documentElement.lang=o:(!o||o==="system")&&navigator.language.startsWith("zh")&&(document.documentElement.lang="zh")}catch{}})();function O(){if(typeof marked>"u")return;const t=new marked.Renderer,e=i=>i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");t.code=function(i,a){let s=i,l=a;typeof i=="object"&&i!==null&&(s=i.text||"",l=i.lang||"");const n=l&&typeof hljs<"u"&&hljs.getLanguage(l)?l:"plaintext";let c;if(typeof hljs<"u"&&n!=="plaintext")try{c=hljs.highlight(s,{language:n}).value}catch{c=e(s)}else c=e(s);return`
<div class="code-block-wrapper">
    <div class="code-header">
        <span class="code-lang">${n}</span>
        <button class="copy-code-btn" aria-label="Copy code">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
            <span>Copy</span>
        </button>
    </div>
    <pre><code class="hljs language-${n}">${c}</code></pre>
</div>`};const o={breaks:!0,gfm:!0,renderer:t};typeof marked.use=="function"?marked.use(o):typeof marked.setOptions=="function"&&marked.setOptions(o)}function w(t){return new Promise((e,o)=>{const i=document.createElement("script");i.src=t,i.onload=e,i.onerror=o,document.head.appendChild(i)})}function q(t){const e=document.createElement("link");e.rel="stylesheet",e.href=t,document.head.appendChild(e)}async function G(){try{const t=w("https://cdn.jsdelivr.net/npm/marked/marked.min.js"),e=new Promise((o,i)=>setTimeout(()=>i("CDN Timeout"),5e3));await Promise.race([t,e]).catch(o=>console.warn("Marked load issue:",o)),O(),q("https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css"),q("https://cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.9.0/build/styles/atom-one-dark.min.css"),Promise.all([w("https://cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.9.0/build/highlight.min.js"),w("https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"),w("https://cdn.jsdelivr.net/npm/fuse.js@7.0.0/dist/fuse.basic.min.js")]).then(()=>w("https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js")).catch(o=>console.warn("Optional libs load failed",o)),console.log("Lazy dependencies loading...")}catch(t){console.warn("Deferred loading failed",t)}}class z{constructor(){this.blocks=[]}protect(e){this.blocks=[];const o=(i,a)=>{e=e.replace(i,(s,l)=>{const n=`@@MATH_BLOCK_${this.blocks.length}@@`;return this.blocks.push({id:n,content:l,isDisplay:a}),n})};return o(/\\\$\$([\s\S]+?)\\\$\$/g,!0),o(/\$\$([\s\S]+?)\$\$/g,!0),o(/\\\[([\s\S]+?)\\\]/g,!0),o(/\\\$([^$]+?)\\\$/g,!1),o(/\\\(([\s\S]+?)\\\)/g,!1),o(new RegExp("(?<!\\\\)\\$([^$\\n]+?)(?<!\\\\)\\$","g"),!1),e}restore(e){return this.blocks.forEach(({id:o,content:i,isDisplay:a})=>{const s=i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),l=a?"$$":"$";e=e.replace(o,`${l}${s}${l}`)}),e}}function F(t){if(typeof marked>"u")return t;const e=new z;let o=e.protect(t||""),i=marked.parse(o);return i=e.restore(i),i}const H="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAGVElEQVR4nMVYvXIbNxD+FvKMWInXmd2dK7MTO7sj9QKWS7qy/Ab2o/gNmCp0JyZ9dHaldJcqTHfnSSF1R7kwlYmwKRYA93BHmkrseMcjgzgA++HbH2BBxhhmBiB/RYgo+hkGSFv/ZOY3b94w89u3b6HEL8JEYCYATCAi2JYiQ8xMDADGWsvMbfVagm6ZLxKGPXr0qN/vJ0mSpqn0RzuU//Wu9MoyPqxmtqmXJYwxxpiAQzBF4x8/fiyN4XDYoZLA5LfEhtg0+glMIGZY6wABMMbs4CaiR8brkYIDwGg00uuEMUTQ1MYqPBRRYZjZ+q42nxEsaYiV5VOapkmSSLvX62VZprUyM0DiQACIGLCAESIAEINAAAEOcQdD4a+2FJqmhDd/YEVkMpmEtrU2igCocNHW13swRBQYcl0enxbHpzEhKo0xSZJEgLIsC4Q5HJaJ2Qg7kKBjwMJyCDciBBcw7fjSO4tQapdi5vF43IZ+cnISdh9Y0At2RoZWFNtLsxr8N6CUTgCaHq3g+Pg4TVO1FACSaDLmgMhYC8sEQzCu3/mQjNEMSTvoDs4b+nXny5cvo4lBJpNJmKj9z81VrtNhikCgTsRRfAklmurxeKx9JZIsy548eeITKJgAQwzXJlhDTAwDgrXkxxCD2GfqgEPa4rnBOlApFUC/39fR1CmTyWQwGAQrR8TonMRNjjYpTmPSmUnC8ODgQHqSJDk7O9uNBkCv15tOp4eHh8SQgBICiCGu49YnSUJOiLGJcG2ydmdwnRcvXuwwlpYkSabTaZS1vyimc7R2Se16z58/f/jw4Z5LA8iy7NmzZ8J76CQ25F2UGsEAJjxo5194q0fn9unp6fHx8f5oRCQ1nJ+fbxtA3HAjAmCMCaGuAQWgh4eH0+k0y7LGvPiU3CVXV1fz+by+WQkCJYaImKzL6SEN6uMpjBVMg8FgOp3GfnNPQADqup79MLv59AlWn75E/vAlf20ibmWg0Pn06dPJZNLr9e6nfLu8//Ahv/gFAEdcWEsgZnYpR3uM9KRpOplMGmb6SlLX9Ww2q29WyjH8+SI+pD0GQJIkJycn/8J/I4mWjaQoijzPb25uJJsjmAwqprIsG4/HbVZ2L/1fpCiKoijKqgTRBlCWZcPhcDQafUVfuZfUdb1cLpfL5cePf9Lr16/3zLz/g9T1quNy+F2FiYjSNB0Oh8Ph8HtRtV6vi6JYLpdVVbmb8t3dnSAbjUbRNfmbSlmWeZ6XHytEUQafEo0xR0dHUdjvG2X3Sd/Fb0We56t6BX8l2mTq6BCVnqOjo7Ozs29hRGGlqqrOr40CIKqeiGg8Hn/xcri/rG/XeZ7/evnrjjGbC3V05YC/BSRJ8urVq36/3zX7Hjaq63o+n19fX/upUqe5VxFok7UBtQ+T6XQ6GAz2Vd6Ssizn8/nt7a3ay1ZAYbMN520XkKenpx0B2E2SLOo+FEWxWPwMgMnC3/adejZMYLLS42r7oH4LGodpsVgURdHQuIcURbFYLDYlVKg9sCk5wpWNiHym9pUAEQGG6EAqSxhilRQWi0VZVmrz23yI5cPV1dX5TwsmWGYrb2TW36OJGjdXhryKxEeHvjR2Fgzz+bu6XnVgaHEmXhytEK0W1aUADJPjAL6CtPZv5rsGSvUKtv7r8/zdj+v1uoOUpsxms7qunT6+g1/TvTQCxE6XR2kBqxjyZo6K66gsAXB1fZ3neQdJSvI8X61WpNaMWCFuKNrkGuGGmMm95fhpvPkn/f6lAgAuLy/LstyGpq7r9+8d4rAr443qaln/ehHt1siv3dvt2B/RDpJms5lGE62gEy9az0XGcQCK3DL4DTPr0pPZEjPAZVlusoCSoihWqzpCHy7ODRXhbUTJly9oDr4fKDaV9NZJUrszPOjsI0a/FzfwNt4eHH+BSyICqK7rqqo0u0VRrFYridyN87L3pBYf7qvq3wqc3DMldJmiK06pgi8uLqQjAAorRG+p+zLUxks+z7rOkOzlIUy8yrAcQFVV3a4/ywBPmJsVMcTM3l/h9xDlLga4I1PDGaD7UNBPuCKBleUfy2gd+DOrPWubGHJJyD+L+LCTjEXEgH//2uSxhu1/Xzocy+VSL+2cUhrqLVZ/jTYL0IMtQEklT3/iWCutzUljDDNXVSVHRFWW7SOtccHag6V/AF1/slVRyOkZAAAAAElFTkSuQmCC",K="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAAfrElEQVR4nJV9zXNc15Xf75zXIuBUjG45M7GyEahFTMhVMUEvhmQqGYJeRPTG1mokbUL5v5rsaM/CkjdDr4b2RqCnKga9iIHJwqCyMCgvbG/ibparBGjwzpnF+bjnvm7Q9isU2Hj93r3nno/f+bgfJOaZqg4EJfglSkSXMtLAKkRETKqqRMM4jmC1Z5hZVZEXEylUiYgAISKBf8sgiKoqDayqIkJEKBeRArh9++7BwcHn558/+8XRz//30cDDOI7WCxGBCYCIZL9EpKoKEKCqzFzpr09aCzZAb628DjAAggBin5UEBCPfuxcRiIpIG2+On8TuZ9Ot9eg+Pxt9+TkIIDBZL9lU/yLv7Czeeeedra2txWLxzv948KXtL9WxGWuS1HzRvlKAFDpKtm8yGMfRPmc7diVtRcA+8GEYGqMBEDEgIpcABKqkSiIMgYoIKQjCIACqojpmQ+v8IrUuRyVJ9pk2qY7Gpon0AIAAJoG+8Z/eaGQp9vb2UloCFRWI6igQJQWEmGbeCBGI7DMpjFpmBhPPBh/zbAATRCEKZSgn2UzEpGyM1iZCKEhBopzq54IiqGqaWw5VtXAkBl9V3dlUpG2iMD7Yncpcex7eIO/tfb3IDbu7u9kaFTv2Xpi1kMUAmJi5ERDWnZprJm/jomCohjJOlAsFATjJVcIwzFgZzNmKqIg29VNVIiW2RkLD1fGo2hoRQYhBAInAmBW/Z0SD9y9KCmJ9663dVB8o3n77bSJ7HUQ08EBEzMxGFyuxjyqErwLDt1FDpUzfBU6n2w6JYnRlrCCljpXMDFUEv9jZFhDoRAYo8jDwMBiVYcwAYI0Y7xuOAvW3KS0zM7NB5jAMwdPR/jSx77755ny+qGqytbV1/fr11Oscnph+a1PDqphErjnGqqp0eYfKlc1mIz4WdStxDWJms8+0IITdyeWoY2sXgHFalQBiEClctswOBETqPlEASXAdxzGG5L7JsA/A/q1bQDEkAoAbN27kDbN6/1FVHSFjNyS3LKLmW1nVbd9NHsRwxBCoYaKqmpyUREl65IYzKDmaVo1iO0aEccHeGUdXnIo4CB+cdpfmrfHA5eVlEXvzdNd3dxtF4V/39/cFKujIJSIaWMmdReqFjGO2ZpaCUGRXc1COvIIOhbNL3acCQDb2Es5YtIIBI3SUgZw7Ah1VBKpQmH0RlCAQ81noVd16UnKMpOBa93twRbvx9t5ivnC1MQ4Rwaxsd7eyu36wUQzkxDMxmd9Rl6uxyaU+du6/sEBERkMrUmSgY97DyGN7pwlc4UqUuq1q0Cgi6LlrHtY0yNQnv5qMZ/23iHexf/OmhXr5ajZycHC/oklqsT1BAYK1lxy/RtCUNphW0uDCZUdJP3UBCgAwmEYVoiEBmyBEauFJ0w4JnGdWSvCHJHK5TimY3BW5hUqNnoxpNkYiWuzM927sdWakjUfXd3cX83mMzBVcRaAGgo0wOA5YvGZdiMjo5sZEA4NLMK2SKAZpumZDViWMgBjgFoHXq0p7YpberAgA5iC0iMgF7r4fKX/nZDSmqvfu3attrne0f+tWCsmxdhhSlao/yp5SkZkpoj6dtN/rshANptFVfZgtsHAJSKYmREqkDNWxSYM5GjWvpIAoGIJIgkR1lPBrEQCqQiwzM91G+ACGYLHz+q39W5UlTkC5c/f2nWvXrjnQBLKk3WlkdqRQESIGKPwdjxp4Fw4XmaVYKKUQqKE+GEqw4COIIZHwYqkpqtpsLeJOs50ItFpgYoJJL1Dl74lEoobLChbqARiGYX9/XzHV3OzU/tza2rp7925VE44rlcJlTi2VqcplXWeQMfVTmg63Cak+UIIXVQXzbHAzjywnHhsQTtSkoapE3GJiu6Tpp/VYs1PjkcHBl+c7+/v7BKoaQ2SOCCDNb27fuX1t65qJmgYWBIIw0eDphRJM8lr426ROMABSQs3FwAB5EDMMM+ZZlXc+gprFQDnMm2salYFGdQEosU+2aFmuMdX+ybdM8kb3/YP788WihUONJiViTVgnbG9/6c7du0Q0ljCKIoJvFBY3VEU2USuQELdMkJhNhKZiGmlTY5CZTyZyImLGLlBNpRUikKmRB2/mHUM7Mj50iYWXcUMI6YmKBX47Ozs3b36jKg4oYgKFNUupWap3bt+Z7+xYDigiSiygcRyppNkM0lHM1ZICMjJUVCz4NtlbVcfZqgohHaEQwUgtlyoYJ9KKT6lKIpLp/LpbMV3wBKIm0OKZoaq/raOM/3qJgkQUEj44OLCRh4ynvjLU2f/c3tp68OBBakcx2FYkMDmJiNmIB3PULjT1j7ciQKnxXQ2UeBgYUHMzAEQvFSNYlYQwQFrEGVA1dE2IQERMAgMEYjCRDzPPKmX2+e0be/vfuBkKktgIoqaGwbMmmL29vTff3I1xewUqC0Cq5nOK6TFqrquqyqoOUi11hPnZsUV8FLHiQAxRRoG0asNExMNg+XdVv57TbQAWR4hLz6Dh0kJEVU0LB/BO6MJEObuakY2td3Hvfvfd7e1t6omMyAUAtBaOyxUm1hHfY5NbwBClC2Sg51qmYJANzx2JjtAxogZk7uspj3PNQx6DYCJmmmkEqESkKqZlKfaDeweL+VxrvFwGktwBoAnU4c4W88X9gwNS8TqBR+3+UGW4KQcR7GGyorcIhyKnETAzgxkDqZKKoZiqZNbUkm/K8K5wfRIUVAiotfcUiKpSqwB6Vqnq6PPVr3713r17zfLXL+rvR9ICdSC/ffvO7u51J52b+mdklLDNnNoRH/q6lUZoHmQjm2UmzUpGhElehIZ0fHE8F4XoQDOGFRXJ80e28iKrEmGQEYl/RMqzGZhFHC/mX955/72/s8jMR7+RR21U8bV9DA159913t7f/HdEAZVI2s4o40Avno14Gs9j9aY1CGth7nsjMEX+LYIQQKUcVqahAKkhyN0EhYajoUfMpLWpwf+/Ba7mDg4OD+c7CzCgUr5MwjCkGF9IqCl0pjTBfLL77ne8YiQ0uu8C6hdfVRWRMv24Wlo4F9Gg+Q0RliqMRMdjT1fWYfKxCmDcBj1kAWADmwAYmZfMCYFXC3x7cu7l/s3aSvxQgTutWr5umi4sPYWoAsHdj787f3CZS1bFiykAzCBGxjKo0jIFKqqPIZdR61GZZmBkggM39JdYyD9mmiLAqVDDhKFFXh88Xwr6iqoQWQVRWpg4CgOj169cP7h1URdCsKJKDVGOcexxMwoCJur3zzjtvvvlmEWpTZx3B/BplfBQSjVG0cC+RyzNEbSqGzPtIiSnQziom7AVgcJ+2mYoSaPAqTxbx3PGJVtS3Mtt8/vr7f/felWijUFFMHFpGiRWzC2Db9f7777/++rwW5y/FFEqho1uHKBMDnGhrHj39jE8ujqqqIMdsq4VZENfGU6UBQGS0e7XMXJ9J866/VTNphkB3dnYePny4tbVV360aMf1btUEzrX3f5+vb29sPH364mM9TZw1rndpWq3HK1wsAOQoeuijRO7Q2lUSQDlut7mPqbNZYp5KJyGZfqjVx5Htl1ghgnr8+//B7Hy4WiylrvK3yO3lAoLCyyENexdT54vXvffi9+Zd3krzWPCmjhoJUw+6cNVNVUlYlJcEwad7wNN8n8vpGIr/VSqg9AAf5Rk1KI8DbMkVsb29/+DC4c7U77741gK55WSIRNXY2ZbTocbH44IMPtra2mNnTV3fBha/FRyNYv0mp1+4ARAOriAXDSqIK5kEtrFQwD5k0O/sJsNS5xARtxYUCTPPXd95/7/2v/sc3oo/SNSHgxP5qk/QETy+d1sI4f4DQyiB5RwFguVz94B9+sFwumVkuPd2hCBpVRxXYDGiUotlm7pQ8MRAoiAY0F6SjqcXANjBVtaUtEQwrs8fvlgTGMwT48pc6Z5D8ev311x9++HA+n1OIpDGIHEpy6M6g6uJTa6x8BlKrqCO8WyffxrXVavXo0aPVapVZVap/zBrYSNtnJWmCV62fAZByA+nIGxiIUiBskYy7ZGtLCb5GoiS3KOoa3FkAJXGpHrrVEBUTPbcgsY83jF+K9dpspmz+13w+//Dhhzs7O4YGCYh1MqrhdLzV1i6VycUasvgaEcN80ybEjBUNHDBkDnxQ7bhjgsolI2+99dZ77723tbUVaw7Mhf8lFxUdydBR+/trPKJ4CsD5+fnHH398dnZm34dTK1ojwp57kJJHaomzFafYqoLD7Jqqyviv5iOTQV3oSMX02yxeV/S8fef2tx98GxvB7y+6NvJigkf9Y+Ytar+Hh4eHP3uao1ARtnRd1Tz1RschyGURREQDzVSViGeqHllVDVJV046CTVZAaBUr++e1115799139/b2/oIB/5nf+3dmlpFuxFfUMwW9ChyfHB8+fbparXzsANEACKACxxq7HD3JEk57nckKzRRrEOr0rk+o2qPsXPeyb/gvr5Ardnd3v/Pud82dV/q6QeJP8GjKkfyNeHddg9Y4st77arX64ccf/f73v4cID1CBxMIdtizMWSMI7xzYxMmBzFAasqShWdBd4uP2GoBr167dPzi4fefOnzvsyajSneczsAC8Wk7vuSjuqm7UoI3COPzZ039+eig2HUDwWg+8dgxEEkIWqDqDEJ6deDYQKcTr8LGMzCbsWwJBRKphVord3d3vfue788V8M3HNbVOSEXyJxyYMqhxZG2TXxeSP3g9ufHH1cvlPT56cnp5G+JmFSDe9EqmIGVchakDeyuds2seZyTyOl4AHkPOdnQcPvr1344ZFfH0E6ExxRhRV8BrN1CG194nR0qwW9BbDqdwpZjjVIwoaqvYRYKj0yeHy5UvYmuVSFOw6goeOnq/Nrr3WKo9j1ZqWyAhGAFuvbd+9e/f2ndvb29ubHA2Zs82eJpy6Mthr/KXmrjc/ENyZ3J+E6Y2hrsDEbfAnJ8efHD5dLpdMM1UFCW2EToB8RqPN0rj9ZyUo37y2de3u3Tt3bt/1GOcV+l+tqR+AM+iqd5uou/rQn8GgK9halcsTDn9/uVwdnxwf//JfVqsVD6gFE9iyX26RdHPtlkZYSgHAErSdxfyb3/zm7dt/s7W1vWlkV4/zFWpy1firt9qoTVfx6CpyOvPsX1aAcHJ8cnh4uFqtmFnkkpkrr+CxDDvuGu6kHu2++ebBwf3d67vxKLDuNeqw1z3OVfHeK4Zn6sCEUcG2WGYtpvuL4tA1oytNOGT/6lenJycnn356CkDEc4OEFwJ7+AdAFbu71/f29m7d2u9UpoYnVw3sFXrRkRufuupUfEFrjVwdBF3ZC2LsiKrAelSl3TvM/Ic//OHs7Ozk5P+enZ3lYigzMWxtbb99Y+/69et7e3tXmhKV1oMEb4XNvF2DpgBUjSX5EP62Mah5/U2hzSsYtNFsJ8C0Rnx8pUmMmkmKrlarFy/Onj9//tvf/na5XNKd/3rnwTsPGgUdCnh+0cF87SZ1ta2gaBR2JE/AuwsCE8ZfwQWahpT55JW2TNMQqQ6qNexfhKQ6Mf/0pz/lO7dbKFwmgaxbLVyaEFy7105lJhFyzyqvJKxHwGVSrNKdXXR8mejZ5FnP4LXeL2sl2jYDiqmaYE0Tvjnxe/fuzba3m02VMnCIND53I6qmUc1nSjQBWise6WiNYi39IZEh6JtyhLLmuHZV9TRnIvF6amqngGZPhgzkAiZE+wbJpIrPzy/48OnTJpM1BEAKk6b369gmH6+6GXpBU4doItA11KgtaNPojV2o1yK5GW8PfOtXgE+17q7jo6NnRAN/5Stf+ev/8Fdf//rXd3enm0omUeYr/Nhffl0BORT68oqoEuXVDS5s7ZWNnNoI4UrnFxfPT391dnZ2enp6cXER6yBdD8fd3es3b+6/9dZb8/l8I+VY49qfc00z1Y6u9ac3RxUdmmn/cG1yveUJg7Sgftw8Pz8/Pjk+PX3+4uw3sdRHPZImanXZTMG+duNrt27t3/jaXhJxZbmno6/knzUXWwvSYClSK25c4Yw6gIdepcSb4G/DY5PnCQDOzl4cPj08++zXICLL46XlsV6Trjuw/GJV1fmXF/fv379586bfs2nDnBhZj32ok0/mX5EuUoQejJgNmPJi3aP/ycG/ysSom0FC082Li4ufPzs6OTlZLpeAwFKuEcaNnA0lWxgdjQ0gYZBqrIwQArCzmO/v79+6ub9YLCpTYOFPDuwqkitY2AjDH13hl4IxtBbLKCZhgze6ITQl0HqmQoCen58/Ozo6Ojq6uDi3u5ZmCSmJTe359AQREc+GtqJFGSQQJfKikk2ejSrMvPPvv3z//v2b+zfTrVYoVcvjwoF0SlyVCx3FmxiU4fb6yHsG1cFr90wPN63li4vznx/9/Ojo6PKLL2SSmDIJKSuRwnbrkA9zKLPPZWrQ9gXaQit7wOrQO/Odb33rW9/4L9+oGjSpARGzqnS2UEOVdW5sMCKsffEnUKWZ/BXX6enzJz958vLlS1X1FQheWeS0GFtCZ3X3WIo5+KKY5stiupaI6opMz3GZANz4z1978ODBYrFoeUKfgmX9xW+/gkEbsXnCkbU7V3iM4v+K7qxWy398/Pizz36TrwwE9X3ABoheurcimRtXaJBnEiWf4GSQ1Wvd58XmGYQ23bt3r+1n2ui101w2lUr6Ofu+KDEpg1IkhH0jU/ZuigmPnh09fXp4fn6eKzU2XsoKUQjIdkBlyZVn4c/iVkxoxzrNXL9xOdb5eHvrjTfe+OCDDyp4b2SQm6F/bgtLu2pHA/5N0L0mgA0S6Rm0XC4f//jxixdnceNKBhGR2L567eaWYRoEoJ/0aK95Md+wRpQAHmw7kACggSG6WCwODg5u7u9vcM9XaRCF9+3jvaicYN15rcfWVzDIGz09ff74x48vLi4A9FseNzNLWZNB1KHqAIqDSMLq6mDK/pmOr6Q2ly+qqsMw/Le//e8H9w4azYRalNow9+AimUxaxCsVa9KR2/Kq0Pe4vcYz4MmTJ89+8YtCrU4MPKew2h0SU6QEk4yk850oWnmtk0EEjHmmi/VRS/q5CMaM8vr16++/957PeRBitdhVCzNcI7qAux+nZ4/UsQxTEXZQdH5+/tGPPn7x4oWq5GxwQQ+NhWXJoDjxhe2Ui6G0HBPWRCTSlpo7BCkTs+olgG4e0rkZGsfJaVLVxWLx8H8+XMznyEmFcCydEoW+ELKy8cqSGLCBy0hccxnYEqHly1UObxPuCMfydj91Bc2LDTSrs/CqI2EGYFMtmOx+S2VhSUZZ4u9QLQS2A1QEwM7O3BffrYWF6YIzBdkQ2uGK53WNWzViUl2ulo++/2i5XKLUQNOOTIQiYqbEakstxRb2JINIbXkU5wrGXGmPbAgZJdcVMOl3y0Ly/M3lWJ9VEkrTMJ84Qu0WW1MutfBV7dO3+ue7y5RTAf3d73//6PuPVqsl+c4aSiKnjdTRZgUvky3/t+zUj09TmjBFNcc5W31suyL8RCHKw3B8N81yufz7//X3v/vd79aGWWq36zqbVW2DHu0fs5ps7GktjdByufqHH/zgjy//qLEsNVdC2+4dKqXV2oCtb23jL1LPq+UZlUrPRAqDc7N0ZVY04SqtfpKJEuHi4vyjH320XC2nbGj+qTXXfdW7+ahBxsq9CMqT0cvl8tH3H33++YWI5BkYuTbQ9rvVrQGq+SFsIltTtYAmFwnDViSWJasEMCnn+o/c/7O+oc46U4UgVGno9GK1XD569Gi5XPYimVgdHGK1vFt4qCV8d0ii6JuwXK3MnAVj2TuWg9dRR49gYhE086BKNVMloE1Lw/fca9jWZJ10YAqocrrpZ2RYkQAUi7EZ2u78L1qtlo8ePfr88/PKlLoDeO3qgc9/ty4pC+SE8/PzR99/9PLly/SheS5FwWYQkc2419XubaRxpd1pH0O0fQwASGEnvqgqg9HtAnEzti0yOQoiUoIyUZyhkZdt0lwtlx9/9BEZpqjz28ZNayq5XpmncFXFLJxzH/3wRy9Xf6y8HmjI0AwA0WDrEicupfQ2ilzqeGknGZF6WFwpKkd0qdoJQxOZNlQKh1/QqY1wcpiGxoJGIrx4cfbkyZP1Nifkls/Ni657Hvv+8PDwsxcv1llsM+vWRJtij73y651edeUzTCozbh5RMAqUZ4PtpFcdY3NGxKDEqcLKUKaBZmzbHdqPeZA2tl8cPXt+ejrhjmqBmG5uVpsfy3XVoYBQHP/yl08PnyLO74PFYoCq2lqvcpnDFekPb/SKDw2qJJ1c/SQT1VFVBlsK3JxixIe2/WCC9iJQ6jCrEqL98QLsx9IN7tmZ/vHx4+VyOZGSa3QN+Vro539NnOZqtfrZz35GsRLOVDt3E0a/1K3QoC4di3NrbPd4t0esrSVXEEFE2OM7AdFA4ExG1NYMeZ1ogLRtjxZIqCorsfp+USJqG/YNgFiVxM4bEugXX3zx+PHjwh7TIMkAoxO8OlxXL2aG98OPP1q+XNnhlVHbU8VIZPu8eojlmalJ4qwL2z2vY/BAea7MyGz5w8DMEWUrQCSxtb1qR9TSNFfJUnDHuCCSu+3HtSCgk7wSPvvss2fPnrW/C+iU9xqUhsdsPvjw6WGNP3PxYI58EkOPl7a6su2P7i9XpWyHSlo7jgrf9MJ22EoXCnpQBLYzUbrWc9QM2DlDMqqVckQYHnl5A/aGuK89PDy06JGyJOQA07kYNbCpnRKtVsunh/88EA/E0QsZPtr+2BybBXuqo51t1vsZCtJtpKNvs40f5pkveGYCD75OkcrG4Xq5JKk75mEiCe9U1SBIPaPoQIqIbLnkxcXF4x//GBQ1HXRtBkpXvrTf//Tkie10HscxZ2JUDZvrTrHkVAviaqSS4p1koFouS/dlHNk2/ChBMJop+k876ETJjpKFxQm2J3qwmDsxi5RFkpUAQCqx9wgqlyFJefHrs+enzwGN0zO7ALlX0XYdnxx/+umnNEQXwyw5q6o0wE5wycsLOHYOCakhDhHleYl+PlnQ7D9gUX/G9rt2WpMMrla9LoHq3aoEXC6bAmWeDRqbEYnoyZMn5+clvHY3EcoySU0IAA4/+aSBURwYpKWGV0liP/CttNLTHF4vM7/UJQGVPd0A2zG/REqkdi6inT4QN4nIj5AzjTBtyvOk1eq4QhAdiAEWOy3DXBwx+dFhY+44U8Ly5erZs6OOhZG71KSMfFETjk9OVqs/QuPssHIsj/q2d/LN3d6bbXGiyBNINY7osfMa1N8gZtsCh/YT3AQrnNNpqE2iVV9SPnX/Uy1RZ0K/rlP+LkesF/WaOvNL7Jm69vhj7S2Xq6dPn5psiwV1dfjCL53NZgapWYGwr7rTZXoie4WX2jjXpzUOJwzAUyUZ9dJ0x2S1TpOI5L4FirMw86AuWPBZKl7G988vzn9+dGQG1ZG9hkLHx79cLv+/siprFKFaO86XEYhzPBKnS17aVMPxxVro9mQ0r+L+SkeCdBhERDU7GwbWmKrLYwZrpBCPDQlSE1fIE9nUkA84enbUIdHkCh6d/Mux1vSvBPf5mW2XUwQ1Odqr9LoqeK24Z+SVLbTxiHSFIiWMowBkx1dmKXNUyd0L1p4hgB/22icc4eDayKwr1ZGBL87PjwyJJl6rGNrxyfFqtWImUmYvALIhZh9JiOrY7acFkba9uDl7wxgMNEnZbFbgAbMQyI9pkIx789gYSz1aME7M5Afx+AL9DZYfR12lrDJCSe5svPKb4+NjoAt2Jn8eHh5WfcmcK1WDqK3+Sl02SiZHLayTRJlzAwrGpm85lMrYDFX4nP5ovPAT4jTP/kIjCAZAZZ6kqnRV2u6ID3CcKc4vly9fnL3oyon+Mgg4PT19+XIVMS6SNZE65MYJrsgdWqyqY0bYSR5EGWTxkZNqft1nt9rJs65B9kdh9rQqmNdEbtXOq21TXwN2ppe0oz4J4JNPPuk1p0XVx8fH6TRblWf0//7AQJB51o7RXkvNxnL8Y3XKG7V7ctOMI3IQ0ZhBHcAzRVffWX/Z74jmUXTrWFjY5xFtHMLWziFSwovffHZ+cR4ZmbMGhOVydfr/Ts1DEClIBaPIZZFfqFU4xzykzjggInZOq/HOUQk6qV4nUJLC4MlwygWAUB8ugOLlPO6CgGwxFSo9yEQyhcrW/bpw0iKOT46zn+AQXrx4kTcA+LKuiVeMRLQ5nYghM5LOqvNGEebYs5HJk8FysjMiRxHBCBKCHUQIAH7y+ERFs3UpR20nFjYbDIBnxH9+ArZKQtJ6evo8JZpx0Mnx/4Hk+fmceUGG4wz1gmHQlrGPqsLOktI4KiKQiJllHHWU/CFVHS8l0heL4DJA4RSy/VscZ5V2A51kSnLBGjUFro4jPgAS/jGqSxM3d3Z2dn5+UaeqV6vl2dlZfdi/KuR5Hk1NHimk6jqqXsOKpakvDg5O8ETq4cVKZEl21LglbDqa9O0ANCOl7vSdzWZZu0SEHhmJ+JKPPINXAIniKwXeNBPW0+e/qkHlr399FosuOs/o+Q3Zrv8WYRANFHBhg7RgbRgGK/INQwisnAOJQC6jqtkBtUUZXcmiqFLnsCYHu6U2orr52NTpZxFwpyP5n3mkVKuSEuHs12f1zumnz52zExQzhBRHfrMA0qYmteWkTbU7T7o9Foe4V12bqN5MR2Do4y772ghXVgiYRUfyVRCggWNWgDRiVq0g2tkp217+MtfsJ+ygDOn09LQG0L/77W+pLSrxBIIpAMGgnAReEgUgtovFqLLsUMNSfAkCQ3IFK1GS6px3LhtIj83iiHydXWVt8wHBzDijwqcE8j9eco+WI1ZLm6zM7RP2Whxfrzit34svzn/ykyfLPyzPz8+f/OTJ6uVLNLrF9qsbd2owXSWan6U73q47YXrioeqVEF4fBvBvwZvfB2giLLAAAAAASUVORK5CYII=";let k=null;class P{constructor(e,o){this.bg48=e,this.bg96=o,this.alphaMaps={}}static async create(){if(k)return k;const e=a=>new Promise((s,l)=>{const n=new Image;n.onload=()=>s(n),n.onerror=l,n.src=a}),[o,i]=await Promise.all([e(H),e(K)]);return k=new P(o,i),k}calculateAlphaMap(e,o,i){const a=document.createElement("canvas");a.width=o,a.height=i;const s=a.getContext("2d");s.drawImage(e,0,0);const l=s.getImageData(0,0,o,i),{data:n}=l,c=new Float32Array(o*i);for(let d=0;d<c.length;d++){const r=d*4,u=n[r],g=n[r+1],v=n[r+2];c[d]=Math.max(u,g,v)/255}return c}getAlphaMap(e){if(this.alphaMaps[e])return this.alphaMaps[e];const o=e===48?this.bg48:this.bg96,i=this.calculateAlphaMap(o,e,e);return this.alphaMaps[e]=i,i}async remove(e){const o=new Image;await new Promise((y,m)=>{o.onload=y,o.onerror=m,o.src=e});const i=o.width,a=o.height;let s=48,l=32,n=32;i>1024&&a>1024&&(s=96,l=64,n=64);const c=this.getAlphaMap(s),d=document.createElement("canvas");d.width=i,d.height=a;const r=d.getContext("2d");r.drawImage(o,0,0);const u=r.getImageData(0,0,i,a),g=u.data,v=i-l-s,p=a-n-s,h=.002,b=.99,I=255;for(let y=0;y<s;y++)for(let m=0;m<s;m++){const M=p+y,S=v+m;if(M>=a||S>=i)continue;const V=y*s+m;let f=c[V];if(f<h)continue;f=Math.min(f,b);const j=1-f,R=(M*i+S)*4;for(let C=0;C<3;C++){const N=(g[R+C]-f*I)/j;g[R+C]=Math.max(0,Math.min(255,Math.round(N)))}}return r.putImageData(u,0,0),d.toDataURL("image/png")}}class Z{static async process(e){return(await P.create()).remove(e)}}function xe(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(t){var e=Math.random()*16|0,o=t=="x"?e:e&3|8;return o.toString(16)}).toUpperCase()}function W(t){if(!t)return null;const e=t.split("?");let o=e[0];const i=e.slice(1).join("?");return o=o.replace(/=[a-zA-Z0-9_-]+$/,""),o+="=s0",o+(i?"?"+i:"")}function Y(){document.body.innerHTML="",G(),window.addEventListener("message",async t=>{if(t.data.action==="RENDER"){const{text:e,reqId:o,images:i}=t.data;try{let a=F(e);typeof katex<"u"&&(a=a.replace(/\$\$([\s\S]+?)\$\$/g,(l,n)=>{try{return katex.renderToString(n,{displayMode:!0,throwOnError:!1})}catch{return l}}),a=a.replace(new RegExp("(?<!\\$)\\$(?!\\$)([^$\\n]+?)(?<!\\$)\\$","g"),(l,n)=>{try{return katex.renderToString(n,{displayMode:!1,throwOnError:!1})}catch{return l}}));const s=[];if(i&&Array.isArray(i)&&i.length>0){let l='<div class="generated-images-grid">';[i[0]].forEach(c=>{const d="gen_img_"+Date.now()+"_"+Math.random().toString(36).substr(2,9),r=W(c.url);l+=`<img class="generated-image loading" alt="${c.alt||"Generated Image"}" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxIDEiPjwvc3ZnPg==" data-req-id="${d}">`,s.push({reqId:d,url:r})}),l+="</div>",a+=l}t.source.postMessage({action:"RENDER_RESULT",html:a,reqId:o,fetchTasks:s},{targetOrigin:"*"})}catch(a){console.error("Render error",a),t.source.postMessage({action:"RENDER_RESULT",html:e,reqId:o},{targetOrigin:"*"})}}if(t.data.action==="PROCESS_IMAGE"){const{base64:e,reqId:o}=t.data;try{const i=await Z.process(e);t.source.postMessage({action:"PROCESS_IMAGE_RESULT",base64:i,reqId:o},{targetOrigin:"*"})}catch(i){console.warn("Watermark removal failed in renderer",i),t.source.postMessage({action:"PROCESS_IMAGE_RESULT",base64:e,reqId:o,error:i.message},{targetOrigin:"*"})}}})}const Q="modulepreload",J=function(t){return"/"+t},D={},E=function(e,o,i){let a=Promise.resolve();if(o&&o.length>0){let l=function(d){return Promise.all(d.map(r=>Promise.resolve(r).then(u=>({status:"fulfilled",value:u}),u=>({status:"rejected",reason:u}))))};document.getElementsByTagName("link");const n=document.querySelector("meta[property=csp-nonce]"),c=(n==null?void 0:n.nonce)||(n==null?void 0:n.getAttribute("nonce"));a=l(o.map(d=>{if(d=J(d),d in D)return;D[d]=!0;const r=d.endsWith(".css"),u=r?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${d}"]${u}`))return;const g=document.createElement("link");if(g.rel=r?"stylesheet":Q,r||(g.as="script"),g.crossOrigin="",g.href=d,c&&g.setAttribute("nonce",c),document.head.appendChild(g),r)return new Promise((v,p)=>{g.addEventListener("load",v),g.addEventListener("error",()=>p(new Error(`Unable to preload CSS for ${d}`)))})}))}function s(l){const n=new Event("vite:preloadError",{cancelable:!0});if(n.payload=l,window.dispatchEvent(n),!n.defaultPrevented)throw l}return a.then(l=>{for(const n of l||[])n.status==="rejected"&&s(n.reason);return e().catch(s)})},X=`
    <!-- SIDEBAR -->
    <div id="history-sidebar" class="sidebar">
        <div class="sidebar-top">
            <div class="search-container">
                <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input type="text" id="history-search" data-i18n-placeholder="searchPlaceholder" placeholder="Search for chats" autocomplete="off">
            </div>
        </div>
        
        <div class="history-list-label" data-i18n="recentLabel">Recent</div>
        <div id="history-list" class="history-list"></div>

        <div class="sidebar-footer">
            <button id="settings-btn" class="settings-btn">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                <span data-i18n="settings">Settings</span>
            </button>
        </div>
    </div>
    <div id="sidebar-overlay" class="sidebar-overlay"></div>
`,_=`
<div class="setting-group">
    <h4 data-i18n="connection">Connection</h4>
    
    <div style="margin-bottom: 12px;">
        <label data-i18n="connectionProvider" style="font-weight: 500; display: block; margin-bottom: 6px;">Model Provider</label>
        <select id="provider-select" class="shortcut-input" style="width: 100%; text-align: left; padding: 8px 12px;">
            <option value="web" data-i18n="providerWeb">Gemini Web Client (Free)</option>
            <option value="official" data-i18n="providerOfficial">Google Gemini API</option>
            <option value="openai" data-i18n="providerOpenAI">OpenAI Compatible API</option>
        </select>
    </div>
    
    <div id="api-key-container" style="display: none; flex-direction: column; gap: 12px; margin-bottom: 12px; padding: 12px; background: rgba(0,0,0,0.03); border-radius: 8px;">
        <!-- Official API Fields -->
        <div id="official-fields" style="display: none; flex-direction: column; gap: 12px;">
            <div>
                <label style="font-weight: 500; display: block; margin-bottom: 2px;">Base URL</label>
                <input type="text" id="official-base-url" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" placeholder="https://generativelanguage.googleapis.com">
            </div>
            <div>
                <label data-i18n="apiKey" style="font-weight: 500; display: block; margin-bottom: 2px;">API Key</label>
                <input type="password" id="api-key-input" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" data-i18n-placeholder="apiKeyPlaceholder" placeholder="Paste your Gemini API Key">
            </div>
            <div>
                <label style="font-weight: 500; display: block; margin-bottom: 2px;">Thinking Level (Gemini 3)</label>
                <select id="thinking-level-select" class="shortcut-input" style="width: 100%; text-align: left; padding: 6px 12px;">
                    <option value="minimal">Minimal (Flash Only)</option>
                    <option value="low">Low (Faster)</option>
                    <option value="medium">Medium (Balanced)</option>
                    <option value="high">High (Deep Reasoning)</option>
                </select>
            </div>
        </div>

        <!-- OpenAI Fields -->
        <div id="openai-fields" style="display: none; flex-direction: column; gap: 12px;">
            <!-- Config Management Section -->
            <div>
                <label data-i18n="openaiConfigSection" style="font-weight: 500; display: block; margin-bottom: 6px;">API Configuration</label>
                <div style="display: flex; gap: 8px; align-items: center;">
                    <select id="openai-config-select" class="shortcut-input" style="flex: 1; text-align: left; padding: 6px 12px;"></select>
                    <button id="openai-add-config" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="openaiAddConfig">Add</button>
                    <button id="openai-remove-config" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="openaiRemoveConfig">Remove</button>
                </div>
            </div>
            
            <div id="openai-config-status" style="font-size: 12px; color: #4CAF50; opacity: 0.9; display: none;"></div>
            
            <div>
                <label data-i18n="openaiConfigName" style="font-weight: 500; display: block; margin-bottom: 2px;">Configuration Name</label>
                <input type="text" id="openai-config-name" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" data-i18n-placeholder="openaiConfigNamePlaceholder" placeholder="e.g. Production API">
            </div>
            <div>
                <label data-i18n="baseUrl" style="font-weight: 500; display: block; margin-bottom: 2px;">Base URL</label>
                <input type="text" id="openai-base-url" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" data-i18n-placeholder="baseUrlPlaceholder" placeholder="https://api.openai.com/v1">
            </div>
            <div>
                <label data-i18n="apiKey" style="font-weight: 500; display: block; margin-bottom: 2px;">API Key</label>
                <input type="password" id="openai-api-key" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" data-i18n-placeholder="apiKeyPlaceholder" placeholder="sk-...">
            </div>
            <div>
                <label style="font-weight: 500; display: block; margin-bottom: 2px;">Model IDs (Comma separated)</label>
                <input type="text" id="openai-model" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" placeholder="e.g. gpt-4o, claude-3-5-sonnet">
            </div>
            <div>
                <label data-i18n="openaiTimeout" style="font-weight: 500; display: block; margin-bottom: 2px;">Timeout (ms)</label>
                <input type="number" id="openai-timeout" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" placeholder="60000" value="60000">
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" id="openai-set-default" />
                    <span data-i18n="openaiSetDefault">Set as Default</span>
                </label>
            </div>
        </div>
    </div>

    <div style="margin-top: 12px; padding: 12px; background: rgba(0,0,0,0.03); border-radius: 8px;">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px;">
            <div>
                <label data-i18n="mcpTools" style="font-weight: 500; display: block; margin-bottom: 2px;">External MCP Tools</label>
                <div data-i18n="mcpToolsDesc" style="font-size: 12px; opacity: 0.85;">Connect to a local/remote MCP server and use its tools in chat.</div>
            </div>
            <label style="display: flex; align-items: center; gap: 8px;">
                <input type="checkbox" id="mcp-enabled" />
                <span data-i18n="enabled">Enabled</span>
            </label>
        </div>

        <div id="mcp-fields" style="display: none; flex-direction: column; gap: 12px; margin-top: 12px;">
            <div>
                <label data-i18n="mcpActiveServers" style="font-weight: 500; display: block; margin-bottom: 6px;">Active Servers</label>
                <div data-i18n="mcpMultiServerHint" style="font-size: 11px; opacity: 0.75; margin-bottom: 8px;">Check multiple servers to use them together.</div>
                <div id="mcp-server-list" style="max-height: 150px; overflow: auto; padding: 8px; background: rgba(255,255,255,0.55); border-radius: 8px; border: 1px solid rgba(0,0,0,0.06); display: flex; flex-direction: column; gap: 6px;"></div>
                <div style="display: flex; gap: 8px; align-items: center; margin-top: 8px;">
                    <button id="mcp-add-server" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="mcpAddServer">Add</button>
                    <button id="mcp-remove-server" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="mcpRemoveServer">Remove</button>
                </div>
            </div>

            <div>
                <label data-i18n="mcpServerName" style="font-weight: 500; display: block; margin-bottom: 2px;">Name</label>
                <input type="text" id="mcp-server-name" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" placeholder="Local Proxy">
            </div>
            <div>
                <label data-i18n="mcpTransport" style="font-weight: 500; display: block; margin-bottom: 2px;">Transport</label>
                <select id="mcp-transport" class="shortcut-input" style="width: 100%; text-align: left; padding: 6px 12px;">
                    <option value="sse">SSE (http://.../sse)</option>
                    <option value="streamable-http">Streamable HTTP (http://.../mcp)</option>
                    <option value="ws">WebSocket (ws://)</option>
                </select>
            </div>
            <div>
                <label data-i18n="mcpServerUrl" style="font-weight: 500; display: block; margin-bottom: 2px;">Server URL</label>
                <input type="text" id="mcp-server-url" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" placeholder="http://127.0.0.1:3006/sse">
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px;">
                <label style="display: flex; align-items: center; gap: 8px;">
                    <input type="checkbox" id="mcp-server-enabled" />
                    <span data-i18n="enabled">Enabled</span>
                </label>
                <button id="mcp-test-connection" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="mcpTestConnection">Test</button>
            </div>
            <div id="mcp-test-status" style="font-size: 12px; opacity: 0.85;"></div>

            <div style="margin-top: 6px; padding-top: 10px; border-top: 1px solid rgba(0,0,0,0.06); display: flex; flex-direction: column; gap: 10px;">
                <div>
                    <label data-i18n="mcpToolMode" style="font-weight: 500; display: block; margin-bottom: 6px;">Expose Tools</label>
                    <select id="mcp-tool-mode" class="shortcut-input" style="width: 100%; text-align: left; padding: 6px 12px;">
                        <option value="all" data-i18n="mcpToolModeAll">All tools (default)</option>
                        <option value="selected" data-i18n="mcpToolModeSelected">Selected tools only</option>
                    </select>
                </div>

                <div style="display: flex; gap: 8px; align-items: center;">
                    <button id="mcp-refresh-tools" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="mcpRefreshTools">Refresh Tools</button>
                    <button id="mcp-enable-all-tools" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="mcpEnableAllTools">Enable All</button>
                    <button id="mcp-disable-all-tools" class="tool-btn" style="padding: 6px 10px;" type="button" data-i18n="mcpDisableAllTools">Disable All</button>
                </div>

                <input type="text" id="mcp-tool-search" class="shortcut-input" style="width: 100%; text-align: left; box-sizing: border-box;" data-i18n-placeholder="mcpToolSearchPlaceholder" placeholder="Search tools...">

                <div id="mcp-tools-summary" style="font-size: 12px; opacity: 0.85;"></div>

                <div id="mcp-tool-list" style="max-height: 220px; overflow: auto; padding: 8px; background: rgba(255,255,255,0.55); border-radius: 8px; border: 1px solid rgba(0,0,0,0.06);"></div>
            </div>
        </div>
    </div>
</div>`,$=`
<div class="setting-group">
    <h4 data-i18n="general">General</h4>
    
    <div class="shortcut-row" style="margin-bottom: 12px;">
        <div style="flex: 1;">
            <label data-i18n="textSelection" style="font-weight: 500; display: block; margin-bottom: 2px;">Text Selection Toolbar</label>
            <span class="setting-desc" data-i18n="textSelectionDesc">Show floating toolbar when selecting text.</span>
        </div>
        <input type="checkbox" id="text-selection-toggle" style="width: 20px; height: 20px; cursor: pointer;">
    </div>

    <div class="shortcut-row" style="margin-bottom: 12px;">
        <div style="flex: 1;">
            <label data-i18n="imageToolsToggle" style="font-weight: 500; display: block; margin-bottom: 2px;">Show Image Tools Button</label>
            <span class="setting-desc" data-i18n="imageToolsToggleDesc">Show the AI button when hovering over images.</span>
        </div>
        <input type="checkbox" id="image-tools-toggle" style="width: 20px; height: 20px; cursor: pointer;">
    </div>

    <div class="shortcut-row" style="margin-bottom: 12px; align-items: flex-start;">
        <div style="flex: 1; margin-right: 12px;">
            <label data-i18n="accountIndices" style="font-weight: 500; display: block; margin-bottom: 2px;">Account Indices</label>
            <span class="setting-desc" data-i18n="accountIndicesDesc">Comma-separated user indices (e.g., 0, 1, 2) for polling.</span>
        </div>
        <input type="text" id="account-indices-input" class="shortcut-input" style="width: 100px; text-align: left;" placeholder="0">
    </div>

    <div style="margin-top: 16px;">
        <h5 data-i18n="sidebarBehavior" style="margin: 0 0 8px 0; font-size: 14px; font-weight: 600; color: var(--text-primary);">When Sidebar Reopens</h5>
        
        <div style="display: flex; flex-direction: column; gap: 12px;">
            <label style="display: flex; align-items: flex-start; gap: 8px; cursor: pointer;">
                <input type="radio" name="sidebar-behavior" value="auto" style="margin-top: 3px;">
                <div>
                    <div data-i18n="sidebarBehaviorAuto" style="font-weight: 500; font-size: 14px; color: var(--text-primary);">Auto restore or restart</div>
                    <div data-i18n="sidebarBehaviorAutoDesc" style="font-size: 12px; color: var(--text-tertiary);">Restore if opened within 10 mins, otherwise start new chat.</div>
                </div>
            </label>
            
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                <input type="radio" name="sidebar-behavior" value="restore">
                <span data-i18n="sidebarBehaviorRestore" style="font-size: 14px; color: var(--text-primary);">Always restore previous chat</span>
            </label>
            
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                <input type="radio" name="sidebar-behavior" value="new">
                <span data-i18n="sidebarBehaviorNew" style="font-size: 14px; color: var(--text-primary);">Always start new chat</span>
            </label>
        </div>
    </div>
</div>`,ee=`
<div class="setting-group">
    <h4 data-i18n="appearance">Appearance</h4>
    <div class="shortcut-row">
        <label data-i18n="theme">Theme</label>
        <select id="theme-select" class="shortcut-input" style="width: auto; padding: 6px 12px; text-align: left;">
            <option value="system" data-i18n="system">System Default</option>
            <option value="light" data-i18n="light">Light</option>
            <option value="dark" data-i18n="dark">Dark</option>
        </select>
    </div>
    <div class="shortcut-row">
        <label data-i18n="language">Language</label>
        <select id="language-select" class="shortcut-input" style="width: auto; padding: 6px 12px; text-align: left;">
            <option value="system" data-i18n="system">System Default</option>
            <option value="en">English</option>
            <option value="zh">中文</option>
        </select>
    </div>
</div>`,te=`
<div class="setting-group">
    <h4 data-i18n="keyboardShortcuts">Keyboard Shortcuts</h4>
    <p class="setting-desc" style="margin-bottom: 12px;" data-i18n="shortcutDesc">Click input and press keys to change.</p>
    
    <div class="shortcut-row">
        <label data-i18n="quickAsk">Quick Ask (Floating)</label>
        <input type="text" id="shortcut-quick-ask" class="shortcut-input" readonly value="Ctrl+G">
    </div>
    
    <div class="shortcut-row">
        <label data-i18n="openSidePanel">Open Side Panel</label>
        <input type="text" id="shortcut-open-panel" class="shortcut-input" readonly value="Alt+S">
    </div>

    <div class="shortcut-row">
        <label data-i18n="shortcutBrowserControl">Open Browser Control</label>
        <input type="text" id="shortcut-browser-control" class="shortcut-input" readonly value="Ctrl+B">
    </div>

    <div class="shortcut-row">
        <label data-i18n="shortcutFocusInput">Focus Input</label>
        <input type="text" class="shortcut-input" readonly value="Ctrl+P">
    </div>

    <div class="shortcut-row">
        <label data-i18n="shortcutSwitchModel">Switch Model</label>
        <input type="text" class="shortcut-input" readonly value="Tab">
    </div>

    <div class="settings-actions">
        <button id="reset-shortcuts" class="btn-secondary" data-i18n="resetDefault">Reset Default</button>
        <button id="save-shortcuts" class="btn-primary" data-i18n="saveChanges">Save Changes</button>
    </div>
</div>`,oe=`
<div class="setting-group">
    <h4 data-i18n="dataManagement">Data Management</h4>
    
    <!-- Export Section -->
    <div class="shortcut-row" style="margin-bottom: 16px; flex-direction: column; align-items: stretch;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
            <div style="flex: 1;">
                <label data-i18n="exportConfigs" style="font-weight: 500; display: block; margin-bottom: 2px;">Export Configurations</label>
                <span class="setting-desc" data-i18n="exportConfigsDesc">Export all OpenAI API configurations to a JSON file for backup or migration.</span>
            </div>
            <button id="export-configs-btn" class="btn-secondary" style="padding: 8px 16px; font-size: 13px; white-space: nowrap; margin-left: 12px;">
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 4px; margin-top: -2px;">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                <span data-i18n="exportButton">Export</span>
            </button>
        </div>
        <div id="export-status" class="data-operation-status" style="display: none; font-size: 12px; padding: 6px 10px; border-radius: 6px; margin-top: 4px;"></div>
    </div>

    <!-- Divider -->
    <div style="height: 1px; background: var(--border-color); margin: 16px 0; opacity: 0.5;"></div>

    <!-- Import Section -->
    <div class="shortcut-row" style="flex-direction: column; align-items: stretch;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
            <div style="flex: 1;">
                <label data-i18n="importConfigs" style="font-weight: 500; display: block; margin-bottom: 2px;">Import Configurations</label>
                <span class="setting-desc" data-i18n="importConfigsDesc">Import OpenAI API configurations from a previously exported JSON file.</span>
            </div>
        </div>
        
        <!-- Drop Zone -->
        <div id="import-drop-zone" class="import-drop-zone" style="
            border: 2px dashed var(--border-color);
            border-radius: 12px;
            padding: 24px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            background: var(--bg-secondary);
            margin-bottom: 12px;
        ">
            <div id="drop-zone-content">
                <svg viewBox="0 0 24 24" width="32" height="32" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round" style="display: block; margin: 0 auto 8px; opacity: 0.5;">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="17 8 12 3 7 8"></polyline>
                    <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
                <p style="margin: 0; color: var(--text-secondary); font-size: 13px;" data-i18n="dropZoneText">Drop JSON file here or click to select</p>
                <p style="margin: 4px 0 0; color: var(--text-tertiary); font-size: 11px;" data-i18n="dropZoneHint">Supports .json files exported from Chubby Cat</p>
            </div>
            <input type="file" id="import-file-input" accept=".json" style="display: none;">
        </div>

        <!-- Import Options -->
        <div id="import-options" style="display: none; margin-bottom: 12px; padding: 12px; background: var(--bg-tertiary); border-radius: 8px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                <span style="font-size: 13px; font-weight: 500; color: var(--text-primary);" data-i18n="importMode">Import Mode</span>
            </div>
            <div style="display: flex; gap: 12px;">
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px; color: var(--text-secondary);">
                    <input type="radio" name="import-mode" value="merge" checked style="margin: 0;">
                    <span data-i18n="importModeMerge">Merge (keep existing)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px; color: var(--text-secondary);">
                    <input type="radio" name="import-mode" value="replace" style="margin: 0;">
                    <span data-i18n="importModeReplace">Replace (overwrite all)</span>
                </label>
            </div>
        </div>

        <!-- File Preview -->
        <div id="import-preview" style="display: none; margin-bottom: 12px; padding: 12px; background: var(--bg-tertiary); border-radius: 8px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                <span style="font-size: 13px; font-weight: 500; color: var(--text-primary);" data-i18n="filePreview">File Preview</span>
                <button id="import-clear-btn" class="btn-link" style="font-size: 11px; color: var(--text-tertiary); padding: 2px 6px;" data-i18n="clearSelection">Clear</button>
            </div>
            <div id="import-preview-content" style="font-size: 12px; color: var(--text-secondary);"></div>
        </div>

        <!-- Import Button & Status -->
        <div style="display: flex; align-items: center; gap: 12px;">
            <button id="import-configs-btn" class="btn-primary" style="padding: 8px 16px; font-size: 13px; flex-shrink: 0;" disabled>
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 4px; margin-top: -2px;">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="17 8 12 3 7 8"></polyline>
                    <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
                <span data-i18n="importButton">Import</span>
            </button>
            <div id="import-status" class="data-operation-status" style="display: none; font-size: 12px; padding: 6px 10px; border-radius: 6px; flex: 1;"></div>
        </div>
    </div>

    <!-- Divider -->
    <div style="height: 1px; background: var(--border-color); margin: 16px 0; opacity: 0.5;"></div>

    <!-- Security Warning -->
    <div class="security-notice" style="
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 12px;
        background: rgba(255, 193, 7, 0.1);
        border: 1px solid rgba(255, 193, 7, 0.3);
        border-radius: 8px;
        font-size: 12px;
        color: var(--text-secondary);
    ">
        <svg viewBox="0 0 24 24" width="18" height="18" stroke="#FFC107" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; margin-top: 1px;">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
        <div>
            <p style="margin: 0 0 4px; font-weight: 500; color: var(--text-primary);" data-i18n="securityWarningTitle">Security Notice</p>
            <p style="margin: 0; line-height: 1.4;" data-i18n="securityWarningText">Exported files contain your API keys in plain text. Store them securely and never share them publicly. Only import files from trusted sources.</p>
        </div>
    </div>
</div>`,ie=`
<div class="setting-group">
    <h4 data-i18n="system">System</h4>
    <div class="shortcut-row">
        <label data-i18n="debugLogs">Debug Logs</label>
        <button id="download-logs" class="btn-secondary" style="padding: 6px 12px; font-size: 12px;" data-i18n="downloadLogs">Download Logs</button>
    </div>
</div>

<div class="setting-group">
    <h4 data-i18n="about">About</h4>
    <p class="setting-info">
        <strong>Chubby Cat</strong> 
        <span id="app-current-version">v1.0.0</span>
        <span id="app-update-status" style="font-size: 13px; margin-left: 8px; font-weight: normal;"></span>
    </p>
    
    <div style="display: flex; gap: 16px; margin-top: 8px; flex-wrap: wrap;">
        <a href="https://github.com/hallfay0/chubby-cat" target="_blank" class="github-link" style="margin-top: 0;">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
            <span data-i18n="sourceCode">Source Code</span>
            <span id="star-count" class="star-badge"></span>
        </a>
        
        <a href="https://github.com/hallfay0/chubby-cat/blob/main/README.md" target="_blank" class="github-link" style="margin-top: 0;">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
                <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
                <line x1="6" y1="1" x2="6" y2="4"></line>
                <line x1="10" y1="1" x2="10" y2="4"></line>
                <line x1="14" y1="1" x2="14" y2="4"></line>
            </svg>
            <span data-i18n="buyMeCoffee">Buy Me a Coffee</span>
        </a>
    </div>
</div>`,ne=`
    <!-- SETTINGS -->
    <div id="settings-modal" class="settings-modal">
        <div class="settings-content">
            <div class="settings-header">
                <h3 data-i18n="settingsTitle">Settings</h3>
                <button id="close-settings" class="icon-btn small" data-i18n-title="close" title="Close">✕</button>
            </div>
            <div class="settings-body">
                ${_}
                ${$}
                ${ee}
                ${te}
                ${oe}
                ${ie}
            </div>
        </div>
    </div>
`,ae=`
    <!-- HEADER -->
    <div class="header">
        <div class="header-left">
            <button id="history-toggle" class="icon-btn" data-i18n-title="toggleHistory" title="Chat History">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
            
            <div class="model-select-wrapper">
                <select id="model-select" data-i18n-title="modelSelectTooltip" title="Select Model (Tab to cycle)">
                    <option value="gemini-3-flash">Fast</option>
                    <option value="gemini-3-flash-thinking">Thinking</option>
                    <option value="gemini-3-pro">3 Pro</option>
                </select>
            </div>
        </div>

        <div class="header-right">
            <button id="tab-switcher-btn" class="icon-btn" style="display: none;" data-i18n-title="selectTabTooltip" title="Select a tab to control">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M2 6h20v13a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6z"/>
                    <path d="M2 6l2.5-3.5A2 2 0 0 1 6.1 1h11.8a2 2 0 0 1 1.6 1.5L22 6"/>
                </svg>
            </button>
            <button id="new-chat-header-btn" class="icon-btn" data-i18n-title="newChatTooltip" title="New Chat">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            </button>
        </div>
    </div>

    <!-- Corner Button -->
    <button id="open-full-page-btn" class="corner-btn" data-i18n-title="openFullPageTooltip" title="Open in Full Page">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
    </button>
`,se=`
    <!-- CHAT AREA -->
    <div id="chat-history"></div>
`,le=`
    <!-- FOOTER -->
    <div class="footer">
        <div id="status"></div>
        
        <!-- Active Tab Display Container with Dropdown -->
        <div class="active-tab-container" id="active-tab-container">
            <!-- Multi-Tab Dropdown Panel (向上展开) -->
            <div class="multi-tab-dropdown" id="multi-tab-dropdown">
                <div class="multi-tab-dropdown-header">
                    <span class="multi-tab-count" id="multi-tab-count" data-i18n="noTabSelected">No tab selected</span>
                    <div class="multi-tab-actions">
                        <button class="multi-tab-action-btn" id="multi-tab-select-all" data-i18n="selectAll">Select All</button>
                        <button class="multi-tab-action-btn" id="multi-tab-deselect-all" data-i18n="deselectAll">Deselect All</button>
                    </div>
                </div>
                <div class="multi-tab-list" id="multi-tab-list"></div>
            </div>
            
            <!-- Active Tab Display Area -->
            <div class="active-tab-display" id="active-tab-display" data-i18n-title="activeTabTooltip" title="Click to select tabs for context import">
                <div class="active-tab-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M2 6h20v13a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6z"/>
                        <path d="M2 6l2.5-3.5A2 2 0 0 1 6.1 1h11.8a2 2 0 0 1 1.6 1.5L22 6"/>
                    </svg>
                </div>
                <span class="active-tab-title" id="active-tab-title" data-i18n="loadingActiveTab">Loading...</span>
                <div class="active-tab-chevron">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="18 15 12 9 6 15"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="tools-container">
            <button id="tools-scroll-left" class="scroll-nav-btn left" aria-label="Scroll Left">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
            
            <div class="tools-row" id="tools-row">
                <button id="browser-control-btn" class="tool-btn" data-i18n-title="browserControlTooltip" title="Allow model to control browser">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m3 3 7.07 16.97 2.51-7.39 7.39-2.51L3 3z"></path>
                        <path d="m13 13 6 6"></path>
                    </svg>
                    <span data-i18n="browserControl">Control</span>
                </button>
                <button id="page-context-btn" class="tool-btn context-aware" data-i18n-title="pageContextTooltip" title="Toggle chat with page content">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="9" y1="3" x2="9" y2="21"></line>
                    </svg>
                    <span data-i18n="pageContext">Page</span>
                </button>
                <button id="quote-btn" class="tool-btn context-aware" data-i18n-title="quoteTooltip" title="Quote selected text from page">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/>
                        <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/>
                    </svg>
                    <span data-i18n="quote">Quote</span>
                </button>
                <button id="ocr-btn" class="tool-btn context-aware" data-i18n-title="ocrTooltip" title="Capture area and extract text">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 7V4h3"></path>
                        <path d="M20 7V4h-3"></path>
                        <path d="M4 17v3h3"></path>
                        <path d="M20 17v3h-3"></path>
                        <line x1="9" y1="12" x2="15" y2="12"></line>
                    </svg>
                    <span data-i18n="ocr">OCR</span>
                </button>
                <button id="screenshot-translate-btn" class="tool-btn context-aware" data-i18n-title="screenshotTranslateTooltip" title="Capture area and translate text">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m5 8 6 6"></path><path d="m4 14 6-6 2-3"></path><path d="M2 5h12"></path><path d="M7 2h1"></path><path d="m22 22-5-10-5 10"></path><path d="M14 18h6"></path>
                    </svg>
                    <span data-i18n="screenshotTranslate">Translate</span>
                </button>
                <button id="snip-btn" class="tool-btn context-aware" data-i18n-title="snipTooltip" title="Capture area to input">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2v14a2 2 0 0 0 2 2h14"></path>
                        <path d="M18 22V8a2 2 0 0 0-2-2H2"></path>
                    </svg>
                    <span data-i18n="snip">Snip</span>
                </button>
            </div>

            <button id="tools-scroll-right" class="scroll-nav-btn right" aria-label="Scroll Right">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>
        </div>

        <div class="input-wrapper">
            <!-- Dynamic Image Preview Container -->
            <div id="image-preview" class="image-preview"></div>
            
            <div class="input-row">
                <label id="upload-btn" data-i18n-title="uploadImageTooltip" title="Upload File">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>
                    <input type="file" id="image-input" multiple accept="image/*, .pdf, .txt, .js, .py, .html, .css, .json, .csv, .md" style="display: none;">
                </label>
                <textarea id="prompt" data-i18n-placeholder="askPlaceholder" placeholder="Ask Gemini..." rows="1"></textarea>
                <button id="send" data-i18n-title="sendMessageTooltip" title="Send message">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                </button>
            </div>
        </div>
    </div>
`,re=`
    <!-- IMAGE VIEWER -->
    <div id="image-viewer" class="image-viewer">
        <div class="viewer-container" id="viewer-container">
            <img class="viewer-content" id="full-image" draggable="false" referrerpolicy="no-referrer">
        </div>
        
        <div class="viewer-toolbar">
            <button id="viewer-zoom-out" data-i18n-title="zoomOut" title="Zoom Out (Scroll Down)">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            </button>
            <span id="viewer-zoom-level">100%</span>
            <button id="viewer-zoom-in" data-i18n-title="zoomIn" title="Zoom In (Scroll Up)">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            </button>
            <div class="viewer-divider"></div>
            <button id="viewer-reset" data-i18n-title="resetZoom" title="Fit to Screen (Double Click)">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>
            </button>
            <button id="viewer-download" data-i18n-title="downloadImage" title="Download Image">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
            </button>
            <div class="viewer-divider"></div>
            <button id="viewer-close" data-i18n-title="close" title="Close (Esc)">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
    </div>
`,de=`
    <!-- TAB SELECTOR MODAL -->
    <div id="tab-selector-modal" class="settings-modal">
        <div class="settings-content">
            <div class="settings-header">
                <h3 data-i18n="selectTab">Select Active Tab</h3>
                <button id="close-tab-selector" class="icon-btn small" data-i18n-title="close" title="Close">✕</button>
            </div>
            <div class="settings-body">
                <div id="tab-list" class="history-list"></div>
            </div>
        </div>
    </div>
`;function ce(){const t=X+ae+se+le+re+ne+de,e=document.getElementById("app");e&&(e.innerHTML=t)}const pe={en:{searchPlaceholder:"Search for chats",recentLabel:"Recent",noConversations:"No conversations found.",settings:"Settings",chatHistory:"Chat History",newChat:"New Chat",pageContext:"Page",browserControl:"Browser Control",quote:"Quote",ocr:"OCR",snip:"Snip",screenshotTranslate:"Translate",uploadImage:"Upload Image",askPlaceholder:"Ask Chubby Cat...",sendMessage:"Send message",stopGenerating:"Stop generating",settingsTitle:"Settings",general:"General",connection:"Connection",connectionProvider:"Model Provider",providerWeb:"Chubby Cat Web Client (Free)",providerOfficial:"Google AI API",providerOpenAI:"OpenAI Compatible API",mcpTools:"External MCP Tools",mcpToolsDesc:"Connect to an MCP server and use its tools in chat.",mcpActiveServer:"Active Server",mcpActiveServers:"Active Servers",mcpSelectServers:"Select servers to use",mcpNoServerSelected:"No server selected",mcpMultiServerHint:"Check multiple servers to use them together. All selected tools will be available.",mcpAddServer:"Add",mcpRemoveServer:"Remove",mcpServerName:"Name",mcpTestConnection:"Test Connection",mcpToolMode:"Expose Tools",mcpToolModeAll:"All tools (default)",mcpToolModeSelected:"Selected tools only",mcpRefreshTools:"Refresh Tools",mcpEnableAllTools:"Enable All",mcpDisableAllTools:"Disable All",mcpToolSearchPlaceholder:"Search tools...",mcpTransport:"MCP Transport",mcpServerUrl:"MCP Server URL",enabled:"Enabled",useOfficialApiDesc:"Use your own API key with Flash models.",apiKey:"API Key",apiKeyPlaceholder:"Paste your API Key",baseUrl:"Base URL",baseUrlPlaceholder:"e.g. https://api.openai.com/v1",modelId:"Model ID",modelIdPlaceholder:"e.g. gpt-4o, claude-3-5-sonnet",openaiConfigSection:"API Configuration",openaiAddConfig:"Add",openaiRemoveConfig:"Remove",openaiConfigName:"Configuration Name",openaiConfigNamePlaceholder:"e.g. Production API",openaiTimeout:"Timeout (ms)",openaiSetDefault:"Set as Default",textSelection:"Text Selection Toolbar",textSelectionDesc:"Show floating toolbar when selecting text.",imageToolsToggle:"Show Image Tools Button",imageToolsToggleDesc:"Show the AI button when hovering over images.",sidebarBehavior:"When Sidebar Reopens",sidebarBehaviorAuto:"Auto restore or restart",sidebarBehaviorAutoDesc:"Restore if opened within 10 mins, otherwise start new chat.",sidebarBehaviorRestore:"Always restore previous chat",sidebarBehaviorNew:"Always start new chat",accountIndices:"Account Indices (Multi-account)",accountIndicesDesc:"Comma-separated user indices (e.g., 0, 1, 2) for polling.",appearance:"Appearance",theme:"Theme",language:"Language",keyboardShortcuts:"Keyboard Shortcuts",shortcutDesc:"Click input and press keys to change.",quickAsk:"Quick Ask (Floating)",openSidePanel:"Open Side Panel",openExtension:"Open Extension",shortcutFocusInput:"Focus Input",shortcutSwitchModel:"Switch Model (in Input)",shortcutBrowserControl:"Open Browser Control",resetDefault:"Reset Default",saveChanges:"Save Changes",system:"System",debugLogs:"Debug Logs",downloadLogs:"Download Logs",about:"About",sourceCode:"Source Code",buyMeCoffee:"Buy Me a Coffee",system:"System Default",light:"Light",dark:"Dark",pageContextActive:"Chat with page is already active",pageContextEnabled:"Chat will include page content",cancelled:"Cancelled.",thinking:"Chubby Cat is thinking...",deleteChatConfirm:"Delete this chat?",delete:"Delete",imageSent:"Image sent",selectOcr:"Select area for OCR...",selectSnip:"Select area to capture...",selectTranslate:"Select area to translate...",processingImage:"Processing image...",failedLoadImage:"Failed to load image.",errorScreenshot:"Error processing screenshot.",noTextSelected:"No text selected on page.",ocrPrompt:"Please OCR this image. Extract the text content exactly as is, without any explanation.",screenshotTranslatePrompt:"Please extract the text from this image and translate it into English. Output ONLY the translation.",loadingImage:"Loading image...",readingPage:"Reading page content...",pageReadSuccess:"Read page content (~{count} chars)",regenerate:"Regenerate",regenerating:"Regenerating...",toggleHistory:"Chat History",newChatTooltip:"New Chat",pageContextTooltip:"Toggle chat with page content",browserControlTooltip:"Allow model to control the browser",quoteTooltip:"Quote selected text from page",ocrTooltip:"Capture area and extract text",screenshotTranslateTooltip:"Capture area and translate text",snipTooltip:"Capture area to input",removeImage:"Remove image",uploadImageTooltip:"Upload Image",zoomOut:"Zoom Out",zoomIn:"Zoom In",resetZoom:"Fit to Screen",downloadImage:"Download Image",close:"Close",sendMessageTooltip:"Send message",openFullPageTooltip:"Open in full page",modelSelectTooltip:"Select Model (Tab to cycle)",modelGroupWeb:"── Web (Free) ──",modelGroupOfficial:"── Official API ──",modelGroupOpenAI:"── Custom API ──",providerSwitching:"Switching model provider...",providerSwitched:"Switched to {provider}",providerSwitchError:"Failed to switch provider",noApiKeyConfigured:"No API key configured for this provider",selectTab:"Select Active Tab",selectTabTooltip:"Select a tab to control",noTabsFound:"No open tabs found.",lockTab:"Lock Tab",unlockTab:"Unlock Tab (Auto-follow Active)",activeTab:"Current Tab",activeTabTooltip:"Click to select tabs for context import",selectTabsForContext:"Select Tabs for Context",selectTabsDesc:"Select one or more tabs to import their content as context",selectedTabsCount:"{count} tab(s) selected",importSelectedTabs:"Import Selected",noTabSelected:"No tab selected",importingTabs:"Importing tab content...",tabsImported:"Imported {count} tab(s) content",loadingActiveTab:"Loading...",selectAll:"Select All",deselectAll:"Deselect All",dataManagement:"Data Management",exportConfigs:"Export Configurations",exportConfigsDesc:"Export all OpenAI API configurations to a JSON file for backup or migration.",exportButton:"Export",importConfigs:"Import Configurations",importConfigsDesc:"Import OpenAI API configurations from a previously exported JSON file.",importButton:"Import",dropZoneText:"Drop JSON file here or click to select",dropZoneHint:"Supports .json files exported from Chubby Cat",importMode:"Import Mode",importModeMerge:"Merge (keep existing)",importModeReplace:"Replace (overwrite all)",filePreview:"File Preview",clearSelection:"Clear",securityWarningTitle:"Security Notice",securityWarningText:"Exported files contain your API keys in plain text. Store them securely and never share them publicly. Only import files from trusted sources."},zh:{mcpTools:"外部 MCP 工具",mcpToolsDesc:"连接到 MCP 服务器，并在对话中调用其工具。",mcpActiveServer:"当前服务器",mcpActiveServers:"激活的服务器",mcpSelectServers:"选择要使用的服务器",mcpNoServerSelected:"未选择服务器",mcpMultiServerHint:"勾选多个服务器可同时使用它们，所有选中服务器的工具都将可用。",mcpAddServer:"添加",mcpRemoveServer:"移除",mcpServerName:"名称",mcpTestConnection:"测试连接",mcpToolMode:"工具暴露方式",mcpToolModeAll:"全部工具（默认）",mcpToolModeSelected:"仅选择的工具",mcpRefreshTools:"刷新工具列表",mcpEnableAllTools:"全部启用",mcpDisableAllTools:"全部禁用",mcpToolSearchPlaceholder:"搜索工具...",mcpTransport:"MCP 传输方式",mcpServerUrl:"MCP 服务器地址",enabled:"启用",searchPlaceholder:"搜索对话",recentLabel:"最近",noConversations:"未找到对话。",settings:"设置",chatHistory:"历史记录",newChat:"新对话",pageContext:"网页",browserControl:"浏览器控制",quote:"引用",ocr:"OCR",snip:"截图",screenshotTranslate:"截图翻译",uploadImage:"上传图片",askPlaceholder:"询问猫猫...",sendMessage:"发送消息",stopGenerating:"停止生成",settingsTitle:"设置",general:"常规",connection:"连接",connectionProvider:"模型来源",providerWeb:"猫猫 网页版 (免费)",providerOfficial:"Google AI 官方 API",providerOpenAI:"OpenAI 兼容 API",useOfficialApiDesc:"使用自定义 API Key (Flash 模型)。",apiKey:"API Key",apiKeyPlaceholder:"粘贴 API Key",baseUrl:"Base URL (接口地址)",baseUrlPlaceholder:"例如 https://api.openai.com/v1",modelId:"模型 ID",modelIdPlaceholder:"例如 gpt-4o, claude-3-5-sonnet",openaiConfigSection:"API 配置",openaiAddConfig:"添加",openaiRemoveConfig:"移除",openaiConfigName:"配置名称",openaiConfigNamePlaceholder:"例如 生产环境",openaiTimeout:"超时时间 (ms)",openaiSetDefault:"设为默认",textSelection:"划词工具栏",textSelectionDesc:"选中网页文本时显示悬浮工具栏。",imageToolsToggle:"显示图片工具按钮",imageToolsToggleDesc:"鼠标悬停在图片上时显示 AI 按钮。",sidebarBehavior:"当侧边栏重新打开时",sidebarBehaviorAuto:"自动恢复或重新开始",sidebarBehaviorAutoDesc:"如果在10分钟内重新打开，聊天将恢复；如果超过10分钟，将开始新的聊天",sidebarBehaviorRestore:"始终恢复上次的聊天",sidebarBehaviorNew:"始终开始新的聊天",accountIndices:"多账号轮询 (Account Indices)",accountIndicesDesc:"输入逗号分隔的账号索引值 (如 0, 1, 7) 以开启轮询。",appearance:"外观",theme:"主题",language:"语言",keyboardShortcuts:"快捷键",shortcutDesc:"点击输入框并按下按键以修改。",quickAsk:"快速提问 (悬浮)",openSidePanel:"打开侧边栏",openExtension:"打开扩展",shortcutFocusInput:"聚焦输入框",shortcutSwitchModel:"切换模型 (输入框内)",shortcutBrowserControl:"打开浏览器控制",resetDefault:"恢复默认",saveChanges:"保存更改",system:"系统",debugLogs:"调试日志",downloadLogs:"下载日志",about:"关于",sourceCode:"源代码",buyMeCoffee:"请我喝咖啡",system:"跟随系统",light:"浅色",dark:"深色",pageContextActive:"网页对话已激活",pageContextEnabled:"对话将包含网页内容",cancelled:"已取消",thinking:"猫猫 正在思考...",deleteChatConfirm:"确认删除此对话？",delete:"删除",imageSent:"图片已发送",selectOcr:"请框选要识别的区域...",selectSnip:"请框选要截图的区域...",selectTranslate:"请框选要翻译的区域...",processingImage:"正在处理图片...",failedLoadImage:"图片加载失败。",errorScreenshot:"截图处理出错。",noTextSelected:"页面上未选择文本。",ocrPrompt:"请识别并提取这张图片中的文字 (OCR)。仅输出识别到的文本内容，不需要任何解释。",screenshotTranslatePrompt:"请识别这张图片中的文字并将其翻译成中文。仅输出翻译后的内容。",loadingImage:"正在加载图片...",readingPage:"正在读取网页内容...",pageReadSuccess:"已读取网页内容 (约 {count} 字)",regenerate:"重新回答",regenerating:"正在重新生成...",toggleHistory:"历史记录",newChatTooltip:"新对话",pageContextTooltip:"切换网页上下文对话",browserControlTooltip:"允许模型控制浏览器",quoteTooltip:"引用网页选中内容",ocrTooltip:"区域截图 (OCR文字提取)",screenshotTranslateTooltip:"截取区域并翻译文字",snipTooltip:"区域截图 (作为图片输入)",removeImage:"移除图片",uploadImageTooltip:"上传图片",zoomOut:"缩小",zoomIn:"放大",resetZoom:"适应屏幕",downloadImage:"下载图片",close:"关闭",sendMessageTooltip:"发送消息",openFullPageTooltip:"新标签页打开",modelSelectTooltip:"选择模型 (按 Tab 切换)",modelGroupWeb:"── 网页版 (免费) ──",modelGroupOfficial:"── 官方 API ──",modelGroupOpenAI:"── 自定义 API ──",providerSwitching:"正在切换模型来源...",providerSwitched:"已切换至 {provider}",providerSwitchError:"切换来源失败",noApiKeyConfigured:"该来源未配置 API 密钥",selectTab:"选择活动标签页",selectTabTooltip:"选择要控制的标签页",noTabsFound:"未找到打开的标签页。",lockTab:"锁定标签页",unlockTab:"解锁 (自动跟随活动标签页)",activeTab:"当前标签页",activeTabTooltip:"点击选择标签页导入内容",selectTabsForContext:"选择标签页导入上下文",selectTabsDesc:"选择一个或多个标签页，将其内容作为上下文导入",selectedTabsCount:"已选择 {count} 个标签页",importSelectedTabs:"导入选中",noTabSelected:"未选择标签页",importingTabs:"正在导入标签页内容...",tabsImported:"已导入 {count} 个标签页内容",loadingActiveTab:"加载中...",selectAll:"全选",deselectAll:"取消全选",dataManagement:"数据管理",exportConfigs:"导出配置",exportConfigsDesc:"将所有 OpenAI API 配置导出为 JSON 文件，用于备份或迁移。",exportButton:"导出",importConfigs:"导入配置",importConfigsDesc:"从之前导出的 JSON 文件中导入 OpenAI API 配置。",importButton:"导入",dropZoneText:"拖放 JSON 文件到此处或点击选择",dropZoneHint:"支持从 Chubby Cat 导出的 .json 文件",importMode:"导入模式",importModeMerge:"合并 (保留现有配置)",importModeReplace:"替换 (覆盖所有)",filePreview:"文件预览",clearSelection:"清除",securityWarningTitle:"安全提示",securityWarningText:"导出的文件包含明文 API 密钥。请安全存储，切勿公开分享。仅从可信来源导入文件。"}};function U(t){return t==="system"?navigator.language.startsWith("zh")?"zh":"en":t}let B="system",T=U(B);try{document.documentElement.lang=T}catch{}function fe(t){B=t,T=U(t),document.documentElement.lang=T}function we(){return B}function x(t){return pe[T][t]||t}function L(){document.querySelectorAll("[data-i18n]").forEach(i=>{const a=i.getAttribute("data-i18n"),s=x(a);s&&(i.textContent=s)}),document.querySelectorAll("[data-i18n-placeholder]").forEach(i=>{const a=i.getAttribute("data-i18n-placeholder"),s=x(a);s&&(i.placeholder=s)}),document.querySelectorAll("[data-i18n-title]").forEach(i=>{const a=i.getAttribute("data-i18n-title"),s=x(a);s&&(i.title=s)})}function A(t){window.parent.postMessage({action:"FORWARD_TO_BACKGROUND",payload:t},"*")}function Ae(t){window.parent.postMessage({action:"SAVE_SESSIONS",payload:t},"*")}function Se(t){window.parent.postMessage({action:"SAVE_SHORTCUTS",payload:t},"*")}function Ce(t){window.parent.postMessage({action:"SAVE_THEME",payload:t},"*")}function ke(t){window.parent.postMessage({action:"SAVE_LANGUAGE",payload:t},"*")}function Ee(){window.parent.postMessage({action:"GET_TEXT_SELECTION"},"*")}function Te(t){window.parent.postMessage({action:"SAVE_TEXT_SELECTION",payload:t},"*")}function Ie(){window.parent.postMessage({action:"GET_IMAGE_TOOLS"},"*")}function Me(t){window.parent.postMessage({action:"SAVE_IMAGE_TOOLS",payload:t},"*")}function Pe(t){window.parent.postMessage({action:"SAVE_SIDEBAR_BEHAVIOR",payload:t},"*")}function Be(){window.parent.postMessage({action:"GET_ACCOUNT_INDICES"},"*")}function Re(t){window.parent.postMessage({action:"SAVE_ACCOUNT_INDICES",payload:t},"*")}function qe(){window.parent.postMessage({action:"GET_CONNECTION_SETTINGS"},"*")}function De(t){window.parent.postMessage({action:"SAVE_CONNECTION_SETTINGS",payload:t},"*")}class ge{constructor(){this.app=null,this.ui=null,this.resizeFn=null,this.queue=[],window.addEventListener("message",this.handleMessage.bind(this))}setApp(e){this.app=e,this.flush()}setUI(e){this.ui=e,this.flush()}setResizeFn(e){this.resizeFn=e}handleMessage(e){const{action:o,payload:i}=e.data;this.app&&this.ui?this.dispatch(o,i,e):this.queue.push({action:o,payload:i,event:e})}flush(){if(this.app&&this.ui)for(;this.queue.length>0;){const{action:e,payload:o,event:i}=this.queue.shift();this.dispatch(e,o,i)}}dispatch(e,o,i){if(e==="RESTORE_SHORTCUTS"){this.ui.updateShortcuts(o);return}if(e==="RESTORE_THEME"){this.ui.updateTheme(o);return}if(e==="RESTORE_LANGUAGE"){this.ui.updateLanguage(o);return}if(e==="RESTORE_MODEL"){if(this.ui.modelSelect){const a=this.ui.modelSelect.value;this.ui.modelSelect.value=o,this.ui.modelSelect.selectedIndex===-1&&(this.ui.modelSelect.value=a||(this.ui.modelSelect.options.length>0?this.ui.modelSelect.options[0].value:""),this.ui.modelSelect.selectedIndex===-1&&this.ui.modelSelect.options.length>0&&(this.ui.modelSelect.selectedIndex=0)),this.resizeFn&&this.resizeFn()}return}if(e==="RESTORE_TEXT_SELECTION"){this.ui.settings.updateTextSelection(o);return}if(e==="RESTORE_IMAGE_TOOLS"){this.ui.settings.updateImageTools(o);return}if(e==="RESTORE_ACCOUNT_INDICES"){this.ui.settings.updateAccountIndices(o);return}if(e==="RESTORE_PROMPT_DRAFT"){this.ui.chat&&this.ui.chat.restorePromptDraft&&this.ui.chat.restorePromptDraft(o);return}if(e==="RESTORE_BROWSER_LOOP_LIMIT"){this.app.handleIncomingMessage(i);return}this.app.handleIncomingMessage(i)}}function ue(t,e,o){document.getElementById("new-chat-header-btn").addEventListener("click",()=>t.handleNewChat());const i=document.getElementById("tab-switcher-btn");i&&i.addEventListener("click",()=>t.handleTabSwitcher());const a=document.getElementById("open-full-page-btn");a&&a.addEventListener("click",()=>{window.parent.postMessage({action:"OPEN_FULL_PAGE"},"*")});const s=document.getElementById("tools-row"),l=document.getElementById("tools-scroll-left"),n=document.getElementById("tools-scroll-right");s&&l&&n&&(l.addEventListener("click",()=>{s.scrollBy({left:-150,behavior:"smooth"})}),n.addEventListener("click",()=>{s.scrollBy({left:150,behavior:"smooth"})}));const c=document.getElementById("browser-control-btn");c&&c.addEventListener("click",()=>{t.toggleBrowserControl(),e.inputFn&&e.inputFn.focus()}),document.getElementById("quote-btn").addEventListener("click",()=>{A({action:"GET_ACTIVE_SELECTION"}),e.inputFn&&e.inputFn.focus()}),document.getElementById("ocr-btn").addEventListener("click",()=>{t.setCaptureMode("ocr"),A({action:"INITIATE_CAPTURE",mode:"ocr",source:"sidepanel"}),e.updateStatus(x("selectOcr"))}),document.getElementById("screenshot-translate-btn").addEventListener("click",()=>{t.setCaptureMode("screenshot_translate"),A({action:"INITIATE_CAPTURE",mode:"screenshot_translate",source:"sidepanel"}),e.updateStatus(x("selectTranslate"))}),document.getElementById("snip-btn").addEventListener("click",()=>{t.setCaptureMode("snip"),A({action:"INITIATE_CAPTURE",mode:"snip",source:"sidepanel"}),e.updateStatus(x("selectSnip"))});const d=document.getElementById("page-context-btn");d&&d.addEventListener("click",()=>{t.togglePageContext(),e.inputFn&&e.inputFn.focus()});const r=document.getElementById("model-select"),u=()=>{if(!r||(r.selectedIndex===-1&&r.options.length>0&&(r.selectedIndex=0),r.selectedIndex===-1))return;const p=document.createElement("span");Object.assign(p.style,{visibility:"hidden",position:"absolute",fontSize:"13px",fontWeight:"500",fontFamily:window.getComputedStyle(r).fontFamily,whiteSpace:"nowrap"}),p.textContent=r.options[r.selectedIndex].text,document.body.appendChild(p);const h=p.getBoundingClientRect().width;document.body.removeChild(p),r.style.width=`${h+34}px`};o&&o(u),r&&(r.addEventListener("change",p=>{const h=p.target.selectedOptions[0];if(!h)return;const b=h.dataset.provider,I=e.getCurrentProvider?e.getCurrentProvider():"web",y=h.dataset.isConfig==="true",m=h.dataset.configId;if(b&&b!==I){if(e.handleProviderSwitch&&e.handleProviderSwitch(b,{configId:y?m:null})){const S={web:"Web (Free)",official:"Official API",openai:"Custom API"};e.updateStatus(`✓ ${S[b]||b}`),setTimeout(()=>e.updateStatus(""),2e3)}}else y&&m&&e.handleOpenaiConfigSwitch&&e.handleOpenaiConfigSwitch(m);t.handleModelChange(p.target.value),u()}),setTimeout(u,50));const g=document.getElementById("prompt"),v=document.getElementById("send");g&&v&&(g.addEventListener("keydown",p=>{if(p.key==="Tab"){if(p.preventDefault(),r){const h=p.shiftKey?-1:1,b=(r.selectedIndex+h+r.length)%r.length;r.selectedIndex=b,r.dispatchEvent(new Event("change"))}return}p.key==="Enter"&&!p.shiftKey&&!p.isComposing&&(p.preventDefault(),v.click())}),v.addEventListener("click",()=>{t.isGenerating?t.handleCancel():t.handleSendMessage()})),document.addEventListener("keydown",p=>{(p.ctrlKey||p.metaKey)&&p.key.toLowerCase()==="p"&&(p.preventDefault(),g&&g.focus())}),document.addEventListener("gemini-regenerate",()=>{t&&t.prompt&&t.prompt.regenerate()})}function he(){ce(),L(),window.parent.postMessage({action:"UI_READY"},"*");const t=new ge;document.addEventListener("gemini-language-changed",()=>{L()}),(async()=>{const[{ImageManager:e},{SessionManager:o},{UIController:i},{AppController:a}]=await Promise.all([E(()=>import("./image_manager-Da5jVvuG.js"),[]),E(()=>import("./session_manager-p50RkTWB.js"),__vite__mapDeps([0,1])),E(()=>import("./ui_controller-CitP4XpQ.js"),__vite__mapDeps([2,3,1])),E(()=>import("./app_controller-BZmRmxMP.js"),__vite__mapDeps([4,3,1]))]),s=new o,l=new i({historyListEl:document.getElementById("history-list"),sidebar:document.getElementById("history-sidebar"),sidebarOverlay:document.getElementById("sidebar-overlay"),statusDiv:document.getElementById("status"),historyDiv:document.getElementById("chat-history"),inputFn:document.getElementById("prompt"),sendBtn:document.getElementById("send"),historyToggleBtn:document.getElementById("history-toggle"),closeSidebarBtn:document.getElementById("close-sidebar"),modelSelect:document.getElementById("model-select")}),n=new e({imageInput:document.getElementById("image-input"),imagePreview:document.getElementById("image-preview"),inputWrapper:document.querySelector(".input-wrapper"),inputFn:document.getElementById("prompt")},{onUrlDrop:d=>{l.updateStatus("Loading image..."),A({action:"FETCH_IMAGE",url:d})}}),c=new a(s,l,n);t.setUI(l),t.setApp(c),ue(c,l,d=>t.setResizeFn(d)),G().then(()=>{c&&c.rerender()}),O()})()}const me=new URLSearchParams(window.location.search),ve=me.get("mode")==="renderer";ve?Y():he();export{Z as W,Pe as a,Me as b,Te as c,we as d,Ie as e,Be as f,xe as g,qe as h,Se as i,Re as j,De as k,Ce as l,fe as m,ke as n,F as o,W as p,Ae as q,Ee as r,A as s,x as t};
